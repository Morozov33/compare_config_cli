import json


def json_format(source):
    return json.dumps(source)
